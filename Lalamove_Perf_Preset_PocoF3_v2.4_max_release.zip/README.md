Lalamove Performance Preset v2.4-max (Aggressive + Safety)
=========================================================

This Magisk module is tuned for POCO F3 (Snapdragon 870) on PixelOS 15.
It aggressively maximizes performance for Lalamove while keeping thermal and battery safety in mind.

Key features:
- Auto-daemon + watchdog (self-heal)
- Per-app auto-switch: Lalamove/Maps -> max profile
- Sets scaling_max_freq to 100% on trigger, min per-core to 60% to keep responsiveness
- stune, read_ahead, tcp tuned for throughput
- Thermal emergency fallback (auto-applies conservative config if sensors >= 50°C)
- Uses 'su -c settings put' fallback for ROMs that block direct settings writes

Defaults (v2.4-max):
- lalamove = 100% (max)
- balanced = 95%
- idle = 65%
- cpu_min_mode = 60%
- read_ahead = 512 KB
- emergency: reduces to safer values automatically

Installation:
1. Copy ZIP to phone.
2. Magisk -> Modules -> Install from storage -> choose ZIP.
3. Reboot.
4. (Optional) Edit /data/local/tmp/lalamove_config.json to adjust percentages or use exact kHz.

Logs:
- /data/local/tmp/lalamove_daemon_v2.4.log
- /data/local/tmp/lalamove_unified_runtime_v2.4.log
- /data/local/tmp/lalamove_watchdog_v2.4.log

Safety:
Monitor temps and battery. If device exceeds safe temps reduce 'lalamove' percent in the config or rely on emergency fallback.

