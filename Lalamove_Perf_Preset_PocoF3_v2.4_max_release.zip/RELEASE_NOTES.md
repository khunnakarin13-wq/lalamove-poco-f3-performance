Release v2.4-max
----------------
Aggressive "max" preset for POCO F3 (PixelOS):
- lalamove -> 100% max freq, cpu_min 60% for low-latency
- Watchdog + daemonized runtime for robust auto operation
- Thermal emergency fallback to protect device at >=50°C
- Su-fallback for settings writes (compat with restrictive ROMs)

Usage: Install via Magisk, reboot.
