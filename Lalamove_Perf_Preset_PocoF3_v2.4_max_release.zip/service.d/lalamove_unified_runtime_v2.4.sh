#!/system/bin/sh
# lalamove_unified_runtime_v2.4.sh
LOG=/data/local/tmp/lalamove_unified_runtime_v2.4.log
exec >> "$LOG" 2>&1
date >> "$LOG"

CONFIG_PATH=/data/local/tmp/lalamove_config.json
STATE_FILE=/data/local/tmp/lalamove_unified_state_v2.4

# defaults (matches previous recommendations)
MODES_LALAMOVE="95%"
MODES_BALANCED="88%"
MODES_IDLE="65%"
CPU_MIN_MODE="55%"
CHECK_INTERVAL=2
TCP_BOOST="westwood"
READ_AHEAD=256
STUNE_TOP=22
STUNE_FG=12
PACKAGES="com.lalamove.driver com.lalamove.global com.lalamove.consumer com.google.android.apps.maps"

# su-settings helper: try 'su -c' then fallback to direct 'settings'
put_setting() {
  key=$1; val=$2
  # try su -c settings first (works where direct settings is blocked)
  su -c "settings put global $key $val" >/dev/null 2>&1 && return 0
  settings put global $key $val >/dev/null 2>&1 && return 0
  return 1
}

# load config if present
if [ -f "$CONFIG_PATH" ]; then
  CFG=$(cat "$CONFIG_PATH" | tr -d '\n' 2>/dev/null)
  v=$(echo "$CFG" | sed -n 's/.*"lalamove"\s*:\s*"\([^"]*\)".*/\1/p'); [ -n "$v" ] && MODES_LALAMOVE="$v"
  v=$(echo "$CFG" | sed -n 's/.*"balanced"\s*:\s*"\([^"]*\)".*/\1/p'); [ -n "$v" ] && MODES_BALANCED="$v"
  v=$(echo "$CFG" | sed -n 's/.*"idle"\s*:\s*"\([^"]*\)".*/\1/p'); [ -n "$v" ] && MODES_IDLE="$v"
  v=$(echo "$CFG" | sed -n 's/.*"cpu_min_mode"\s*:\s*"\([^"]*\)".*/\1/p'); [ -n "$v" ] && CPU_MIN_MODE="$v"
  v=$(echo "$CFG" | sed -n 's/.*"check_interval"\s*:\s*\([0-9]*\).*/\1/p'); [ -n "$v" ] && CHECK_INTERVAL="$v"
  v=$(echo "$CFG" | sed -n 's/.*"tcp"\s*:\s*"\([^"]*\)".*/\1/p'); [ -n "$v" ] && TCP_BOOST="$v"
  v=$(echo "$CFG" | sed -n 's/.*"read_ahead"\s*:\s*\([0-9]*\).*/\1/p'); [ -n "$v" ] && READ_AHEAD="$v"
  v=$(echo "$CFG" | sed -n 's/.*"stune_top"\s*:\s*\([0-9]*\).*/\1/p'); [ -n "$v" ] && STUNE_TOP="$v"
  v=$(echo "$CFG" | sed -n 's/.*"stune_fg"\s*:\s*\([0-9]*\).*/\1/p'); [ -n "$v" ] && STUNE_FG="$v"
fi

echo "[RUNTIME] config lalamove=$MODES_LALAMOVE balanced=$MODES_BALANCED idle=$MODES_IDLE cpu_min=$CPU_MIN_MODE interval=$CHECK_INTERVAL" >> "$LOG"

# choose_freq and compute_min_for_cpu functions (same safe logic)
choose_freq() {
  CPU_DIR="$1"; DESIRED="$2"
  AVAIL_FILE="$CPU_DIR/cpufreq/scaling_available_frequencies"; MAX_FILE="$CPU_DIR/cpufreq/cpuinfo_max_freq"
  if [ -f "$AVAIL_FILE" ]; then AVAIL=$(cat "$AVAIL_FILE" | tr '\n' ' '); elif [ -f "$MAX_FILE" ]; then AVAIL=$(cat "$MAX_FILE"); else echo ""; return; fi
  HIGHEST=$(echo $AVAIL | awk '{print $NF}')
  if [ -z "$DESIRED" ] || [ "$DESIRED" = "null" ]; then echo "$HIGHEST"; return; fi
  case "$DESIRED" in *% ) PERC=$(echo "$DESIRED" | sed 's/%//'); TARGET=$(echo "$HIGHEST" | awk -v p="$PERC" '{printf("%d", $1 * p / 100)}');; * ) TARGET="$DESIRED";; esac
  CHOSEN=""; for f in $AVAIL; do if [ "$f" -le "$TARGET" ]; then CHOSEN="$f"; fi; done; [ -z "$CHOSEN" ] && CHOSEN="$HIGHEST"; echo "$CHOSEN"
}
compute_min_for_cpu() {
  CPU_DIR="$1"; DES="$2"
  AVAIL_FILE="$CPU_DIR/cpufreq/scaling_available_frequencies"; MAX_FILE="$CPU_DIR/cpufreq/scaling_max_freq"
  if [ -f "$AVAIL_FILE" ]; then LIST=$(cat "$AVAIL_FILE"); elif [ -f "$MAX_FILE" ]; then LIST=$(cat "$MAX_FILE"); else echo ""; return; fi
  HIGHEST=$(echo $LIST | awk '{print $NF}') 
  case "$DES" in *%) P=$(echo "$DES" | sed 's/%//'); TARGET=$(( HIGHEST * P / 100 ));; *) TARGET="$DES";; esac
  CHOSEN=""; for f in $LIST; do if [ "$f" -le "$TARGET" ]; then CHOSEN="$f"; fi; done; [ -z "$CHOSEN" ] && CHOSEN="$HIGHEST"; echo "$CHOSEN"
}

# save and restore state
save_state() {
  echo "[SAVE]" >> "$LOG"
  rm -f "$STATE_FILE"
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    [ -f "$cpu/cpufreq/scaling_min_freq" ] && echo "$(basename $cpu) MIN $(cat $cpu/cpufreq/scaling_min_freq)" >> "$STATE_FILE"
    [ -f "$cpu/cpufreq/scaling_max_freq" ] && echo "$(basename $cpu) MAX $(cat $cpu/cpufreq/scaling_max_freq)" >> "$STATE_FILE"
  done
  [ -f /sys/class/kgsl/kgsl-3d0/min_freq ] && echo "GPU_MIN=$(cat /sys/class/kgsl/kgsl-3d0/min_freq)" >> "$STATE_FILE"
  [ -f /dev/stune/top-app/schedtune.boost ] && echo "STUNE_TOP=$(cat /dev/stune/top-app/schedtune.boost)" >> "$STATE_FILE"
  [ -f /dev/stune/foreground/schedtune.boost ] && echo "STUNE_FG=$(cat /dev/stune/foreground/schedtune.boost)" >> "$STATE_FILE"
  [ -f /sys/block/mmcblk0/queue/read_ahead_kb ] && echo "READ_AHEAD=$(cat /sys/block/mmcblk0/queue/read_ahead_kb)" >> "$STATE_FILE"
  [ -f /proc/sys/net/ipv4/tcp_congestion_control ] && echo "TCP=$(cat /proc/sys/net/ipv4/tcp_congestion_control)" >> "$STATE_FILE"
}
restore_state() {
  echo "[RESTORE]" >> "$LOG"
  [ -f "$STATE_FILE" ] || return
  while IFS= read -r line; do
    case "$line" in
      cpu*) cpu=$(echo "$line" | awk '{print $1}'); which=$(echo "$line" | awk '{print $2}'); val=$(echo "$line" | awk '{print $3}'); if [ "$which" = "MIN" ]; then f="/sys/devices/system/cpu/$cpu/cpufreq/scaling_min_freq"; [ -w "$f" ] && echo "$val" > "$f" 2>/dev/null; else f="/sys/devices/system/cpu/$cpu/cpufreq/scaling_max_freq"; [ -w "$f" ] && echo "$val" > "$f" 2>/dev/null; fi ;; 
      GPU_MIN*) val=$(echo "$line" | cut -d= -f2); [ -w /sys/class/kgsl/kgsl-3d0/min_freq ] && echo "$val" > /sys/class/kgsl/kgsl-3d0/min_freq 2>/dev/null; ;;
      STUNE_TOP*) val=$(echo "$line" | cut -d= -f2); [ -w /dev/stune/top-app/schedtune.boost ] && echo "$val" > /dev/stune/top-app/schedtune.boost 2>/dev/null; ;;
      STUNE_FG*) val=$(echo "$line" | cut -d= -f2); [ -w /dev/stune/foreground/schedtune.boost ] && echo "$val" > /dev/stune/foreground/schedtune.boost 2>/dev/null; ;;
      READ_AHEAD*) val=$(echo "$line" | cut -d= -f2); [ -w /sys/block/mmcblk0/queue/read_ahead_kb ] && echo "$val" > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null; ;;
      TCP*) val=$(echo "$line" | cut -d= -f2); [ -w /proc/sys/net/ipv4/tcp_congestion_control ] && echo "$val" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null; ;;
    esac
  done < "$STATE_FILE"
}

# apply UI and CPU and other boosts safely
apply_ui_profile() {
  MODE="$1"
  case "$MODE" in
    lalamove) put_setting window_animation_scale 0; put_setting transition_animation_scale 0; put_setting animator_duration_scale 0; put_setting force_gpu_rendering 1; ;;
    balanced) put_setting window_animation_scale 0.5; put_setting transition_animation_scale 0.5; put_setting animator_duration_scale 0.5; put_setting force_gpu_rendering 1; ;;
    idle) put_setting window_animation_scale 1.0; put_setting transition_animation_scale 1.0; put_setting animator_duration_scale 1.0; put_setting force_gpu_rendering 0; ;;
  esac
}

apply_cpu_caps() {
  MODE_NAME="$1"; DESIRED_MAX="$2"; MIN_SPEC="$3"
  for cpu in /sys/devices/system/cpu/cpu[0-9]*; do
    if [ -f "$cpu/cpufreq/scaling_max_freq" ]; then CHOSEN_MAX=$(choose_freq "$cpu" "$DESIRED_MAX"); [ -n "$CHOSEN_MAX" ] && [ -w "$cpu/cpufreq/scaling_max_freq" ] && echo "$CHOSEN_MAX" > "$cpu/cpufreq/scaling_max_freq" 2>/dev/null; fi
    if [ -f "$cpu/cpufreq/scaling_min_freq" ]; then CHOSEN_MIN=$(compute_min_for_cpu "$cpu" "$MIN_SPEC"); if [ -n "$CHOSEN_MIN" ] && [ -n "$CHOSEN_MAX" ]; then if [ "$CHOSEN_MIN" -gt "$CHOSEN_MAX" ]; then CHOSEN_MIN="$CHOSEN_MAX"; fi; fi; [ -n "$CHOSEN_MIN" ] && [ -w "$cpu/cpufreq/scaling_min_freq" ] && echo "$CHOSEN_MIN" > "$cpu/cpufreq/scaling_min_freq" 2>/dev/null; fi
  done
}

apply_other_boosts() {
  [ -w /dev/stune/top-app/schedtune.boost ] && echo "$STUNE_TOP" > /dev/stune/top-app/schedtune.boost 2>/dev/null
  [ -w /dev/stune/foreground/schedtune.boost ] && echo "$STUNE_FG" > /dev/stune/foreground/schedtune.boost 2>/dev/null
  [ -w /sys/block/mmcblk0/queue/read_ahead_kb ] && echo "$READ_AHEAD" > /sys/block/mmcblk0/queue/read_ahead_kb 2>/dev/null
  [ -w /proc/sys/net/ipv4/tcp_congestion_control ] && echo "$TCP_BOOST" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
}

# helper for top app detection
get_top_app() {
  app=$(dumpsys activity activities 2>/dev/null | grep mResumedActivity | head -n1 | sed -n 's/.* \([^/]*\/[^ ]*\).*/\1/p')
  [ -z "$app" ] && app=$(cmd activity top 2>/dev/null | grep ACTIVITY | head -n1 | awk '{print $NF}' | sed 's/.$//')
  [ -z "$app" ] && app=$(dumpsys window windows 2>/dev/null | grep -E 'mCurrentFocus|mFocusedApp' | head -n1 | sed -n 's/.* \([^ ]*\/[^ ]*\).*/\1/p')
  echo "$app"
}

# main loop: save state once, monitor, apply and restore. includes thermal check
FIRST_RUN=1; PREV=""
while true; do
  # thermal check and emergency adjustment if needed
  max_temp=0
  for t in /sys/class/thermal/thermal_zone*/temp; do
    if [ -f "$t" ]; then val=$(cat "$t" 2>/dev/null); [ -n "$val" ] && [ "$val" -gt "$max_temp" ] && max_temp="$val"; fi
  done
  if [ -n "$max_temp" ] && [ "$max_temp" -ge 50000 ]; then
    # if >=50C, lower local thresholds temporarily
    echo "[THERMAL] $max_temp >= 50000, forcing safer config" >> "$LOG"
    # copy bundled emergency if exists
    emergency="/data/local/tmp/lalamove_emergency.json"
    if [ -f "$emergency" ]; then cp -f "$emergency" "$CONFIG_PATH" 2>/dev/null; fi
  fi
  if [ "$FIRST_RUN" -eq 1 ]; then save_state; FIRST_RUN=0; fi
  TOP=$(get_top_app)
  if [ -n "$TOP" ] && echo "$PACKAGES" | grep -q "$(echo $TOP | cut -d'/' -f1)"; then
    if [ "$TOP" != "$PREV" ]; then
      echo "[TRIGGER] $TOP" >> "$LOG"
      apply_ui_profile lalamove
      apply_cpu_caps "lalamove" "${MODES_LALAMOVE:-95%}" "${CPU_MIN_MODE:-55%}"
      apply_other_boosts
      PREV="$TOP"
    fi
  else
    if [ -n "$PREV" ]; then
      echo "[UNTRIGGER] previous=$PREV" >> "$LOG"
      restore_state
      apply_ui_profile idle
      PREV=""
    fi
  fi
  sleep ${CHECK_INTERVAL:-2}
done
