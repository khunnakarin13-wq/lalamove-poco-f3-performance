#!/system/bin/sh
# 00-lalamove-daemon.sh (v2.4-auto)
# Runs unified controller in background as a resilient daemon. Creates PID file and handles restart.
LOG=/data/local/tmp/lalamove_daemon_v2.4.log
PIDFILE=/data/local/tmp/lalamove_daemon.pid
CONFIG_PATH=/data/local/tmp/lalamove_config.json
RUNTIME=/data/local/tmp/lalamove_unified_runtime.sh

exec >> "$LOG" 2>&1
date >> "$LOG"

# ensure runtime exists (copied by module)
if [ ! -f "$RUNTIME" ]; then
  echo "Runtime not found: $RUNTIME" >> "$LOG"
  exit 1
fi

start_daemon() {
  if [ -f "$PIDFILE" ]; then
    oldpid=$(cat "$PIDFILE" 2>/dev/null)
    if [ -n "$oldpid" ] && kill -0 "$oldpid" 2>/dev/null; then
      echo "Daemon already running (pid $oldpid)" >> "$LOG"
      return 0
    else
      rm -f "$PIDFILE"
    fi
  fi
  # start runtime in background detached
  setsid sh "$RUNTIME" >/dev/null 2>&1 &
  echo $! > "$PIDFILE"
  echo "Started daemon with pid $(cat $PIDFILE)" >> "$LOG"
  return 0
}

stop_daemon() {
  if [ -f "$PIDFILE" ]; then
    pid=$(cat "$PIDFILE")
    kill "$pid" 2>/dev/null || true
    rm -f "$PIDFILE"
    echo "Stopped daemon" >> "$LOG"
  fi
}

# Thermal-check function: if temp too high, scale down config temporarily
thermal_check_and_adjust() {
  # read thermal sensors (best-effort)
  max_temp=0
  for t in /sys/class/thermal/thermal_zone*/temp; do
    if [ -f "$t" ]; then
      val=$(cat "$t" 2>/dev/null)
      [ -n "$val" ] && [ "$val" -gt "$max_temp" ] && max_temp="$val"
    fi
  done
  # temperatures often in millidegree C; threshold = 48°C => 48000
  if [ -z "$max_temp" ]; then
    return 0
  fi
  if [ "$max_temp" -ge 48000 ]; then
    # create an emergency config to reduce max to safer values
    emergency_conf="/data/local/tmp/lalamove_emergency.json"
    if [ ! -f "$emergency_conf" ]; then
      cat > "$emergency_conf" <<EOF
{"lalamove":"85%","balanced":"75%","idle":"60%","cpu_min_mode":"45%","check_interval":3,"tcp":"westwood","read_ahead":128,"stune_top":8,"stune_fg":4}
EOF
    fi
    # if emergency config exists, make it the active config by symlink
    if [ -f "$emergency_conf" ]; then
      ln -sf "$emergency_conf" "$CONFIG_PATH" 2>/dev/null || cp -f "$emergency_conf" "$CONFIG_PATH" 2>/dev/null
      echo "Thermal emergency active: temp=$max_temp" >> "$LOG"
    fi
  fi
}

case "$1" in
  start)
    thermal_check_and_adjust
    start_daemon
    ;;
  stop)
    stop_daemon
    ;;
  restart)
    stop_daemon
    sleep 1
    start_daemon
    ;;
  *)
    # default: start if not running
    thermal_check_and_adjust
    start_daemon
    ;;
esac

exit 0
