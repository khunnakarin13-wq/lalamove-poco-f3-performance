#!/system/bin/sh
# 01-lalamove-watchdog.sh
# Simple watchdog to ensure daemon runs; executed at boot via service.d and loops in background.
LOG=/data/local/tmp/lalamove_watchdog_v2.4.log
PIDFILE=/data/local/tmp/lalamove_daemon.pid
DAEMON_SCRIPT=/data/adb/service.d/00-lalamove-daemon.sh
exec >> "$LOG" 2>&1
date >> "$LOG"

while true; do
  if [ -f "$PIDFILE" ]; then
    pid=$(cat "$PIDFILE" 2>/dev/null)
    if [ -z "$pid" ] || ! kill -0 "$pid" 2>/dev/null; then
      echo "Daemon not running, restarting..." >> "$LOG"
      sh "$DAEMON_SCRIPT" restart
    fi
  else
    echo "PID file missing, starting daemon..." >> "$LOG"
    sh "$DAEMON_SCRIPT" start
  fi
  sleep 10
done
